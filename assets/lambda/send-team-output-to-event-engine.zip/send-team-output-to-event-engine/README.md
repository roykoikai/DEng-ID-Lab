# send-team-output-to-event-engine

## Overview

This Lambda function is deployed in the master account as part of the master CloudFormation (CF) template. 

This function receives a team ID and "Output" key/value pair and makes a call to the Event Engine (EE) API to post the output to the respective team's Event Dashboard. 

## Contents

### api.py

This is a helper module written by the Event Engine team to make it easy to interact with the Event Engine API; in this function, specifically, we use it to send outputs to a given team ID. This is **not** the standard API module you would get from `pip install api`.

### outputmappings.py

This is config file imported by the main `index.py` function. It's use case is described below...

When a team template has a status change it sends the event type and team ID to a lifecycle events SNS topic in the master account. If the event type is MODULE_DEPLOYED, the SNS notification will also include the CloudFormation Outputs(if any) from the team template.

The "handle-master-lifecycle" Lambda is subscribed to this SNS topic and when it receives MODULE_DEPLOYED events, it forwards the team ID and CloudFormation outputs to the function in this directory, "send-team-output-to-event-engine".

The CloudFormation outputs simply contain the Output name and the value; however, the Event Engine Outputs API expects a Key(internal only Value, and Label(visible to customer).CloudFormation Output names cannot contain spaces, punctuation, etc.and are typically CamelCase, which might not make for the best label.

So, this file provides a mapping of CloudFormation Output names to the label that we want to display to the team.If a mapping is not present, the Lambda function will fall back to using a Label name equal to the Output key.

# Other directories (e.g. requests, urllib3, bin, etc)

These are dependencies needed by the `api.py` helper script. 