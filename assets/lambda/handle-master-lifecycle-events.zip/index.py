from __future__ import print_function
import json
import boto3
import os
import traceback
client = boto3.client('lambda')

send_team_output_to_event_engine_function = os.environ['SEND_TEAM_OUTPUT_TO_EVENT_ENGINE_FUNCTION']

print('Loading function')

def handler(event, context):

    try:
        print("Received event: " + json.dumps(event, indent=2))

        message = json.loads(event['Records'][0]['Sns']['Message'])
        event_type = message['event']
        event_id = message['game-id']
        module_id = message['module-id']
        team_id = message['team-id']
        cfn_outputs = {}

        if 'cfn-outputs' in message:
            cfn_outputs = message['cfn-outputs']

        if event_type == 'MODULE_DEPLOYING':
            print('Module {} for event {} for team {} is deploying...'
                    .format(module_id, event_id, team_id)
            )
            print('Nothing to do!')
        elif event_type == 'MODULE_DEPLOYED':
            print('Module {} for event {} for team {} is deployed...'
                    .format(module_id, event_id, team_id)
            )
            if (len(cfn_outputs) == 0):
                print('Team module has no CloudFormation outputs to send to EE')
            else:
                send_initial_team_outputs_to_ee(team_id, cfn_outputs)
        if event_type == 'MODULE_UNDEPLOYING':
            print('Module {} for event {} for team {} is undeploying...'
                    .format(module_id, event_id, team_id)
            )
            print('Nothing to do!')
        if event_type == 'MODULE_UNDEPLOYED':
            print('Module {} for event {} for team {} is undeployed...'
                    .format(module_id, event_id, team_id)
            )
            print('Nothing to do!')
        else:
            print('Module {} for event {} for team {} has unhandled event {}...'
                    .format(module_id, event_id, team_id, event_type)
            )
        return {
            "status": 200,
            "message": "Done!"
        }
    except Exception as e:
        msg = "Unexpected error: {}".format(e)
        print(msg)
        traceback.print_exc()
        return {
            "status": 500,
            "message": msg
        }


def send_initial_team_outputs_to_ee(team_id, cfn_outputs):

    print ('Sending team CloudFormation Outputs to Event Engine...')
    for key, value in cfn_outputs.items():
        payload = {
            "team_id": team_id,
            "output_key": key,
            "output_value": value
        }
        print('Invoking Lambda {} with payload:\n'.format(send_team_output_to_event_engine_function)
            + json.dumps(payload, indent=2)
        )
        response = client.invoke(
            FunctionName=send_team_output_to_event_engine_function,
            InvocationType='RequestResponse',
            Payload=json.dumps(payload),
        )
        response_payload = json.loads(response['Payload'].read())
        print('Invoke response status {}:\n{}'.format(
            response['StatusCode'],
            json.dumps(response_payload,indent=2)
        ))
        