# handle-master-lifecycle-events

## Overview

This Lambda function is deployed in the master account as part of the master CloudFormation (CF) template. 

When an event is deployed, Event Engine (EE) will create an SNS topic in the master account and send notifications to the topic when modules are deploying, deployed, undeploying, or undeployed from team accounts. In addition to the event type itself (e.g. DEPLOYED), these notifications include the event ID, module ID and team ID. For DEPLOYED events, they also the CloudFormation outputs, if any, from the successfully-deployed team template. Example events are in the `./example-events/` directory. 

* Note - there may be other lifecycle events in addition to the ones listed above. Not sure? 

Depending on the event you are building, you may not need any of the info above... however, this can be useful for certain events. 

For example, perhaps team accounts need to interact with resources in the master account via a cross-account role. When a master account receives a lifecycle event informing it of the account ID of a team account, it could trigger a Lambda that creates (or updates) existing roles to include a trust relationship with the team's AWS account ID.

* Note: the SNS messages contain EE team IDs but not the actual AWS account ID. The master account would need to make an API call to the EE API to get the AWS account ID for a given team ID.

## Usage

This function currently only responds to MODULE_DEPLOYED events; specifically, it takes the CloudFormation outputs from the team template (if any) and passes them to the `send-team-outputs-to-event-engine` function so that they show up in the team's EE Dashboard. 

Specifically, these outputs include the Kinesis Data Generator (KDG) sign-in URL for each team's unique Cognito user pool, as well as the username/password for the default user we create in their user pool. 